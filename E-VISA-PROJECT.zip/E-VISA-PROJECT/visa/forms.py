from django import forms
from .models import VisaApplication

class VisaApplicationForm(forms.ModelForm):
    class Meta:
        model = VisaApplication
        fields = [
            "full_name", "email", "nationality", "date_of_birth",
            "passport_number", "visa_type", "purpose", "travel_date",
            "duration", "address", "passport_file", "photo"
        ]
        widgets = {
            "date_of_birth": forms.DateInput(attrs={"type": "date"}),
            "travel_date": forms.DateInput(attrs={"type": "date"}),
            "purpose": forms.Textarea(attrs={"rows": 4, "placeholder": "Briefly explain the purpose of your visit"}),
            "address": forms.Textarea(attrs={"rows": 3, "placeholder": "Current residential address"}),
        }

    def clean_passport_number(self):
        value = self.cleaned_data["passport_number"].strip().upper()
        if len(value) < 6:
            raise forms.ValidationError("Please enter a valid passport number.")
        return value

    def clean_duration(self):
        value = self.cleaned_data["duration"]
        if value < 1 or value > 180:
            raise forms.ValidationError("Duration should be between 1 and 180 days.")
        return value
