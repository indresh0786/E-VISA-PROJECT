from django.contrib import admin
from .models import VisaApplication

@admin.register(VisaApplication)
class VisaApplicationAdmin(admin.ModelAdmin):
    list_display = ("application_id", "full_name", "visa_type", "status", "payment_status", "applied_at")
    list_filter = ("status", "visa_type", "payment_status")
    search_fields = ("application_id", "full_name", "passport_number", "email")
    readonly_fields = ("application_id", "applied_at", "reviewed_at")
