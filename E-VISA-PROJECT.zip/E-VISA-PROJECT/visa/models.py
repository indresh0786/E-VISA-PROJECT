from django.db import models
from django.contrib.auth.models import User
import uuid

class VisaApplication(models.Model):
    VISA_TYPES = [
        ("Tourist", "Tourist"),
        ("Business", "Business"),
        ("Medical", "Medical"),
        ("Student", "Student"),
    ]
    STATUS_CHOICES = [
        ("Pending", "Pending"),
        ("Under Review", "Under Review"),
        ("Approved", "Approved"),
        ("Rejected", "Rejected"),
    ]

    application_id = models.CharField(max_length=20, unique=True, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=120)
    email = models.EmailField()
    nationality = models.CharField(max_length=80)
    date_of_birth = models.DateField()
    passport_number = models.CharField(max_length=30)
    visa_type = models.CharField(max_length=20, choices=VISA_TYPES)
    purpose = models.TextField()
    travel_date = models.DateField()
    duration = models.PositiveIntegerField(help_text="Number of days")
    address = models.TextField()
    passport_file = models.FileField(upload_to="uploads/passports/")
    photo = models.ImageField(upload_to="uploads/photos/", blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="Pending")
    payment_status = models.CharField(max_length=20, default="Unpaid")
    applied_at = models.DateTimeField(auto_now_add=True)
    reviewed_at = models.DateTimeField(blank=True, null=True)
    remarks = models.TextField(blank=True)

    def save(self, *args, **kwargs):
        if not self.application_id:
            self.application_id = "EV" + uuid.uuid4().hex[:10].upper()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.application_id} - {self.full_name}"
