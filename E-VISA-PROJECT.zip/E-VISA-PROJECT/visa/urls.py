from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("register/", views.register_view, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("apply/", views.apply_visa, name="apply_visa"),
    path("application/<str:application_id>/", views.application_detail, name="application_detail"),
    path("application/<str:application_id>/payment/", views.payment, name="payment"),
    path("application/<str:application_id>/certificate/", views.certificate, name="certificate"),
    path("track/", views.track_application, name="track"),
]
