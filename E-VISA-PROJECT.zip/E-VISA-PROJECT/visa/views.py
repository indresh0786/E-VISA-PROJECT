from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from .forms import VisaApplicationForm
from .models import VisaApplication

def home(request):
    return render(request, "home.html")

def register_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password", "")
        if not username or not email or not password:
            messages.error(request, "Please fill all fields.")
        elif User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
        elif User.objects.filter(email=email).exists():
            messages.error(request, "Email is already registered.")
        else:
            user = User.objects.create_user(username=username, email=email, password=password)
            login(request, user)
            messages.success(request, "Account created successfully.")
            return redirect("dashboard")
    return render(request, "register.html")

def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    if request.method == "POST":
        user = authenticate(
            request,
            username=request.POST.get("username", "").strip(),
            password=request.POST.get("password", "")
        )
        if user:
            login(request, user)
            return redirect("dashboard")
        messages.error(request, "Invalid username or password.")
    return render(request, "login.html")

def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("home")

@login_required
def dashboard(request):
    applications = VisaApplication.objects.filter(user=request.user).order_by("-applied_at")
    return render(request, "dashboard.html", {"applications": applications})

@login_required
def apply_visa(request):
    if request.method == "POST":
        form = VisaApplicationForm(request.POST, request.FILES)
        if form.is_valid():
            application = form.save(commit=False)
            application.user = request.user
            application.save()
            messages.success(request, f"Application submitted. Your ID is {application.application_id}.")
            return redirect("application_detail", application_id=application.application_id)
    else:
        form = VisaApplicationForm(initial={"email": request.user.email})
    return render(request, "apply.html", {"form": form})

@login_required
def application_detail(request, application_id):
    application = get_object_or_404(
        VisaApplication, application_id=application_id, user=request.user
    )
    return render(request, "application_detail.html", {"application": application})

@login_required
def payment(request, application_id):
    application = get_object_or_404(
        VisaApplication, application_id=application_id, user=request.user
    )
    if application.payment_status == "Paid":
        return redirect("application_detail", application_id=application.application_id)
    if request.method == "POST":
        application.payment_status = "Paid"
        application.status = "Under Review"
        application.save(update_fields=["payment_status", "status"])
        messages.success(request, "Demo payment completed successfully.")
        return redirect("application_detail", application_id=application.application_id)
    return render(request, "payment.html", {"application": application})

@login_required
def certificate(request, application_id):
    application = get_object_or_404(
        VisaApplication, application_id=application_id, user=request.user
    )
    if application.status != "Approved":
        messages.error(request, "Certificate is available only after approval.")
        return redirect("application_detail", application_id=application.application_id)
    return render(request, "certificate.html", {"application": application})

def track_application(request):
    application = None
    searched = False
    if request.method == "POST":
        searched = True
        application_id = request.POST.get("application_id", "").strip().upper()
        application = VisaApplication.objects.filter(application_id=application_id).first()
    return render(request, "track.html", {"application": application, "searched": searched})
