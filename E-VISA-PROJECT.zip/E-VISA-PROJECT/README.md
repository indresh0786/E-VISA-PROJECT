# E-Visa Management System

A simple Django-based E-Visa Management System made as a college project.

## Features
- Applicant registration and login
- E-Visa application form
- Passport and applicant details
- Document upload
- Application ID generation
- Application status tracking
- Demo payment flow
- Admin dashboard
- Approve / reject applications
- Downloadable visa certificate for approved applications
- Responsive student-friendly interface

## Run locally

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Install packages:
```bash
pip install -r requirements.txt
```

Run migrations:
```bash
python manage.py migrate
```

Create admin:
```bash
python manage.py createsuperuser
```

Start server:
```bash
python manage.py runserver
```

Open:
http://127.0.0.1:8000/

Admin:
http://127.0.0.1:8000/admin/

## Note
This is an academic/demo project. The payment and visa approval workflow are simulated and should not be used as a real government visa service.
